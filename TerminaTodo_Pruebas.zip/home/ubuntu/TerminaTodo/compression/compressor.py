"""
Compressor - Compresión Automática
===================================

Módulo para comprimir archivos automáticamente.
"""

import os
import zipfile
import tarfile
import gzip
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class CompressionFormat(Enum):
    """Formatos de compresión soportados"""
    ZIP = "zip"
    TAR_GZ = "tar.gz"
    GZIP = "gz"
    TAR = "tar"


class Compressor:
    """Gestor de compresión automática"""
    
    # Extensiones comprimibles (no comprimir si ya están comprimidas)
    ALREADY_COMPRESSED = {'.zip', '.gz', '.tar', '.tar.gz', '.rar', '.7z', '.bz2'}
    
    # Extensiones recomendadas para comprimir
    COMPRESSIBLE_EXTENSIONS = {
        '.txt', '.csv', '.json', '.xml', '.log', '.md', '.py', '.js',
        '.html', '.css', '.sql', '.yml', '.yaml', '.conf', '.config',
        '.c', '.cpp', '.h', '.java', '.rb', '.go', '.rs', '.ts'
    }
    
    # Tamaño mínimo para comprimir (en bytes)
    MIN_SIZE_FOR_COMPRESSION = 1024 * 100  # 100 KB
    
    def __init__(self):
        """Inicializa el compresor"""
        self.compression_jobs: Dict[str, Dict] = {}
    
    def should_compress(self, file_path: str) -> Tuple[bool, str]:
        """
        Determina si un archivo debe comprimirse
        
        Args:
            file_path: Ruta del archivo
            
        Returns:
            Tupla (debe_comprimir, razón)
        """
        try:
            file_path = Path(file_path)
            
            # Verificar si existe
            if not file_path.exists():
                return False, "Archivo no existe"
            
            # Verificar si es archivo
            if not file_path.is_file():
                return False, "No es un archivo"
            
            # Verificar si ya está comprimido
            if file_path.suffix.lower() in self.ALREADY_COMPRESSED:
                return False, "Ya está comprimido"
            
            # Verificar tamaño
            file_size = file_path.stat().st_size
            if file_size < self.MIN_SIZE_FOR_COMPRESSION:
                return False, f"Archivo muy pequeño ({file_size} bytes)"
            
            # Verificar extensión
            if file_path.suffix.lower() not in self.COMPRESSIBLE_EXTENSIONS:
                return False, f"Extensión {file_path.suffix} no recomendada"
            
            return True, "Recomendado comprimir"
        
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def compress_file(self, file_path: str, output_path: Optional[str] = None,
                     format: CompressionFormat = CompressionFormat.ZIP) -> Tuple[bool, str]:
        """
        Comprime un archivo
        
        Args:
            file_path: Ruta del archivo
            output_path: Ruta de salida (opcional)
            format: Formato de compresión
            
        Returns:
            Tupla (éxito, mensaje)
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False, "Archivo no existe"
            
            # Generar ruta de salida si no se proporciona
            if not output_path:
                if format == CompressionFormat.ZIP:
                    output_path = f"{file_path}.zip"
                elif format == CompressionFormat.TAR_GZ:
                    output_path = f"{file_path}.tar.gz"
                elif format == CompressionFormat.GZIP:
                    output_path = f"{file_path}.gz"
                else:
                    output_path = f"{file_path}.tar"
            
            output_path = Path(output_path)
            
            # Comprimir según formato
            if format == CompressionFormat.ZIP:
                self._compress_zip(file_path, output_path)
            elif format == CompressionFormat.TAR_GZ:
                self._compress_tar_gz(file_path, output_path)
            elif format == CompressionFormat.GZIP:
                self._compress_gzip(file_path, output_path)
            elif format == CompressionFormat.TAR:
                self._compress_tar(file_path, output_path)
            
            # Calcular ratio
            original_size = file_path.stat().st_size
            compressed_size = output_path.stat().st_size
            ratio = (1 - compressed_size / original_size) * 100
            
            message = f"Comprimido: {original_size/1024:.1f}KB -> {compressed_size/1024:.1f}KB ({ratio:.1f}% reducción)"
            logger.info(message)
            
            return True, message
        
        except Exception as e:
            logger.error(f"Error comprimiendo: {e}")
            return False, f"Error: {str(e)}"
    
    def compress_directory(self, directory: str, output_path: Optional[str] = None,
                          format: CompressionFormat = CompressionFormat.ZIP) -> Tuple[bool, str]:
        """
        Comprime un directorio completo
        
        Args:
            directory: Ruta del directorio
            output_path: Ruta de salida (opcional)
            format: Formato de compresión
            
        Returns:
            Tupla (éxito, mensaje)
        """
        try:
            directory = Path(directory)
            
            if not directory.is_dir():
                return False, "Directorio no existe"
            
            # Generar ruta de salida si no se proporciona
            if not output_path:
                if format == CompressionFormat.ZIP:
                    output_path = f"{directory}.zip"
                elif format == CompressionFormat.TAR_GZ:
                    output_path = f"{directory}.tar.gz"
                else:
                    output_path = f"{directory}.tar"
            
            output_path = Path(output_path)
            
            # Comprimir según formato
            if format == CompressionFormat.ZIP:
                self._compress_directory_zip(directory, output_path)
            elif format == CompressionFormat.TAR_GZ:
                self._compress_directory_tar_gz(directory, output_path)
            elif format == CompressionFormat.TAR:
                self._compress_directory_tar(directory, output_path)
            
            compressed_size = output_path.stat().st_size
            message = f"Directorio comprimido: {compressed_size/1024/1024:.1f}MB"
            logger.info(message)
            
            return True, message
        
        except Exception as e:
            logger.error(f"Error comprimiendo directorio: {e}")
            return False, f"Error: {str(e)}"
    
    def decompress_file(self, file_path: str, output_dir: Optional[str] = None) -> Tuple[bool, str]:
        """
        Descomprime un archivo
        
        Args:
            file_path: Ruta del archivo comprimido
            output_dir: Directorio de salida (opcional)
            
        Returns:
            Tupla (éxito, mensaje)
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False, "Archivo no existe"
            
            if not output_dir:
                output_dir = file_path.parent
            
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # Descomprimir según formato
            if file_path.suffix == '.zip':
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(output_dir)
            elif file_path.name.endswith('.tar.gz'):
                with tarfile.open(file_path, 'r:gz') as tar_ref:
                    tar_ref.extractall(output_dir)
            elif file_path.suffix == '.gz':
                with gzip.open(file_path, 'rb') as gz_ref:
                    output_file = output_dir / file_path.stem
                    with open(output_file, 'wb') as f:
                        f.write(gz_ref.read())
            elif file_path.suffix == '.tar':
                with tarfile.open(file_path, 'r') as tar_ref:
                    tar_ref.extractall(output_dir)
            else:
                return False, "Formato no soportado"
            
            message = f"Descomprimido en: {output_dir}"
            logger.info(message)
            
            return True, message
        
        except Exception as e:
            logger.error(f"Error descomprimiendo: {e}")
            return False, f"Error: {str(e)}"
    
    def get_compression_ratio(self, file_path: str, format: CompressionFormat = CompressionFormat.ZIP) -> Optional[float]:
        """
        Calcula ratio de compresión estimado
        
        Args:
            file_path: Ruta del archivo
            format: Formato de compresión
            
        Returns:
            Ratio de compresión (0-100) o None si error
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return None
            
            # Crear archivo temporal comprimido
            temp_output = Path(f"/tmp/compression_test_{file_path.name}")
            
            success, _ = self.compress_file(str(file_path), str(temp_output), format)
            
            if success:
                original_size = file_path.stat().st_size
                compressed_size = temp_output.stat().st_size
                ratio = (1 - compressed_size / original_size) * 100
                
                # Limpiar
                temp_output.unlink()
                
                return ratio
            
            return None
        
        except Exception as e:
            logger.error(f"Error calculando ratio: {e}")
            return None
    
    # Métodos privados
    
    def _compress_zip(self, file_path: Path, output_path: Path):
        """Comprime a ZIP"""
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(file_path, arcname=file_path.name)
    
    def _compress_tar_gz(self, file_path: Path, output_path: Path):
        """Comprime a TAR.GZ"""
        with tarfile.open(output_path, 'w:gz') as tar:
            tar.add(file_path, arcname=file_path.name)
    
    def _compress_gzip(self, file_path: Path, output_path: Path):
        """Comprime a GZIP"""
        with open(file_path, 'rb') as f_in:
            with gzip.open(output_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
    
    def _compress_tar(self, file_path: Path, output_path: Path):
        """Comprime a TAR"""
        with tarfile.open(output_path, 'w') as tar:
            tar.add(file_path, arcname=file_path.name)
    
    def _compress_directory_zip(self, directory: Path, output_path: Path):
        """Comprime directorio a ZIP"""
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(directory):
                for file in files:
                    file_path = Path(root) / file
                    arcname = file_path.relative_to(directory.parent)
                    zipf.write(file_path, arcname=arcname)
    
    def _compress_directory_tar_gz(self, directory: Path, output_path: Path):
        """Comprime directorio a TAR.GZ"""
        with tarfile.open(output_path, 'w:gz') as tar:
            tar.add(directory, arcname=directory.name)
    
    def _compress_directory_tar(self, directory: Path, output_path: Path):
        """Comprime directorio a TAR"""
        with tarfile.open(output_path, 'w') as tar:
            tar.add(directory, arcname=directory.name)
