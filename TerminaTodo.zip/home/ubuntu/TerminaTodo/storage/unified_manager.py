"""
Unified Storage Manager
======================

Gestor unificado que combina todos los tipos de almacenamiento
en una interfaz única.
"""

import logging
from typing import List, Dict, Optional
from ..storage.local_storage import LocalStorageManager
from ..cloud.cloud_manager import CloudStorageManager
from ..hosting.remote_manager import RemoteStorageManager

logger = logging.getLogger(__name__)


class UnifiedStorageManager:
    """Gestor unificado de almacenamiento"""
    
    def __init__(self):
        self.local_manager = LocalStorageManager()
        self.cloud_manager = CloudStorageManager()
        self.remote_manager = RemoteStorageManager()
    
    def get_all_storage(self) -> Dict:
        """Retorna todos los tipos de almacenamiento disponibles"""
        return {
            "local": self.local_manager.get_storage_status(),
            "cloud": self.cloud_manager.get_cloud_status(),
            "remote": self.remote_manager.get_remote_status()
        }
    
    def get_storage_summary(self) -> Dict:
        """Retorna resumen de almacenamiento"""
        local_status = self.local_manager.get_storage_status()
        cloud_status = self.cloud_manager.get_cloud_status()
        remote_status = self.remote_manager.get_remote_status()
        
        return {
            "local": {
                "type": "Almacenamiento Local",
                "devices": local_status['total_devices'],
                "total_capacity_gb": round(local_status['total_capacity_gb'], 2),
                "available_gb": round(local_status['total_available_gb'], 2),
                "icon": "💾"
            },
            "cloud": {
                "type": "Almacenamiento en Nube",
                "services": cloud_status['total_devices'] if 'total_devices' in cloud_status else 3,
                "authenticated": cloud_status['authenticated_count'],
                "icon": "☁️"
            },
            "remote": {
                "type": "Hosting Privado",
                "servers": remote_status['total_servers'],
                "connected": remote_status['connected_servers'],
                "icon": "🖥️"
            }
        }
    
    def list_all_files(self, storage_type: str, path: str = "/") -> List[Dict]:
        """Lista archivos de un tipo de almacenamiento"""
        try:
            if storage_type == "local":
                files = self.local_manager.list_files(path)
                return [
                    {
                        **f,
                        "storage_type": "local",
                        "icon": "💾"
                    }
                    for f in files
                ]
            
            elif storage_type == "cloud":
                # Aquí se listaría archivos de servicios en nube
                return []
            
            elif storage_type == "remote":
                # Aquí se listaría archivos de servidores remotos
                return []
            
            else:
                logger.error(f"Tipo de almacenamiento no válido: {storage_type}")
                return []
        
        except Exception as e:
            logger.error(f"Error listando archivos: {e}")
            return []
    
    def search_files(self, query: str, storage_types: List[str] = None) -> List[Dict]:
        """Busca archivos en múltiples tipos de almacenamiento"""
        if storage_types is None:
            storage_types = ["local", "cloud", "remote"]
        
        results = []
        
        try:
            # Buscar en almacenamiento local
            if "local" in storage_types:
                for device in self.local_manager.get_devices():
                    files = self.local_manager.list_files(device.mount_point, recursive=True)
                    for f in files:
                        if query.lower() in f['name'].lower():
                            results.append({
                                **f,
                                "storage_type": "local",
                                "device": device.mount_point,
                                "icon": "💾"
                            })
            
            # Buscar en nube (si está implementado)
            if "cloud" in storage_types:
                logger.info("Búsqueda en nube no implementada aún")
            
            # Buscar en hosting privado (si está implementado)
            if "remote" in storage_types:
                logger.info("Búsqueda en hosting privado no implementada aún")
        
        except Exception as e:
            logger.error(f"Error buscando archivos: {e}")
        
        return results
    
    def get_file_info(self, storage_type: str, path: str) -> Optional[Dict]:
        """Obtiene información detallada de un archivo"""
        try:
            if storage_type == "local":
                from pathlib import Path
                p = Path(path)
                
                if not p.exists():
                    return None
                
                stat = p.stat()
                return {
                    "name": p.name,
                    "path": str(p),
                    "is_dir": p.is_dir(),
                    "size_bytes": stat.st_size,
                    "size_mb": round(stat.st_size / (1024**2), 2),
                    "size_gb": round(stat.st_size / (1024**3), 2),
                    "modified": stat.st_mtime,
                    "created": stat.st_ctime,
                    "storage_type": "local"
                }
            
            else:
                logger.error(f"Tipo de almacenamiento no soportado: {storage_type}")
                return None
        
        except Exception as e:
            logger.error(f"Error obteniendo información del archivo: {e}")
            return None
    
    def get_storage_usage_by_type(self) -> Dict:
        """Retorna uso de almacenamiento por tipo"""
        local_status = self.local_manager.get_storage_status()
        
        return {
            "local": {
                "total_gb": round(local_status['total_capacity_gb'], 2),
                "used_gb": round(local_status['total_used_gb'], 2),
                "available_gb": round(local_status['total_available_gb'], 2),
                "usage_percent": round(
                    (local_status['total_used_gb'] / local_status['total_capacity_gb'] * 100)
                    if local_status['total_capacity_gb'] > 0 else 0,
                    1
                )
            },
            "cloud": {
                "authenticated_services": self.cloud_manager.get_cloud_status()['authenticated_count'],
                "total_services": len(self.cloud_manager.services)
            },
            "remote": {
                "connected_servers": self.remote_manager.get_remote_status()['connected_servers'],
                "total_servers": self.remote_manager.get_remote_status()['total_servers']
            }
        }


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("UNIFIED STORAGE MANAGER - EJEMPLO")
    print("=" * 70)
    
    manager = UnifiedStorageManager()
    
    print("\n📊 Resumen de Almacenamiento:")
    summary = manager.get_storage_summary()
    for storage_type, info in summary.items():
        print(f"\n{info['icon']} {info['type']}")
        for key, value in info.items():
            if key not in ['icon', 'type']:
                print(f"  {key}: {value}")
    
    print("\n💾 Uso por Tipo:")
    usage = manager.get_storage_usage_by_type()
    for storage_type, info in usage.items():
        print(f"\n{storage_type.upper()}:")
        for key, value in info.items():
            print(f"  {key}: {value}")
    
    print("\n🔍 Búsqueda de Archivos:")
    results = manager.search_files("*.py", ["local"])
    print(f"Encontrados {len(results)} archivos .py")
    for r in results[:5]:
        print(f"  {r['name']} ({r['size_mb']} MB)")
