"""
Local Storage Manager
====================

Detecta y gestiona almacenamiento local:
- SSD
- HDD
- Pendrives
- Memoria local del sistema
"""

import os
import subprocess
import logging
from typing import List, Dict, Optional
from pathlib import Path
from dataclasses import dataclass
import psutil

logger = logging.getLogger(__name__)


@dataclass
class StorageDevice:
    """Información de un dispositivo de almacenamiento"""
    device_path: str
    mount_point: str
    device_type: str  # ssd, hdd, usb, memory
    total_size_gb: float
    available_size_gb: float
    used_size_gb: float
    filesystem: str
    is_removable: bool
    
    def __str__(self) -> str:
        usage_pct = (self.used_size_gb / self.total_size_gb * 100) if self.total_size_gb > 0 else 0
        return f"{self.device_type.upper()} {self.mount_point}: {self.available_size_gb:.1f}GB/{self.total_size_gb:.1f}GB ({usage_pct:.1f}% usado)"
    
    def to_dict(self) -> Dict:
        """Convertir a diccionario"""
        usage_pct = (self.used_size_gb / self.total_size_gb * 100) if self.total_size_gb > 0 else 0
        return {
            "device": self.device_path,
            "mount_point": self.mount_point,
            "type": self.device_type,
            "total_gb": round(self.total_size_gb, 2),
            "available_gb": round(self.available_size_gb, 2),
            "used_gb": round(self.used_size_gb, 2),
            "usage_percent": round(usage_pct, 1),
            "filesystem": self.filesystem,
            "removable": self.is_removable
        }


class LocalStorageManager:
    """Gestor de almacenamiento local"""
    
    def __init__(self):
        self.devices: List[StorageDevice] = []
        self._detect_devices()
    
    def _detect_devices(self):
        """Detecta todos los dispositivos de almacenamiento local"""
        logger.info("Detectando dispositivos de almacenamiento local...")
        
        try:
            # Usar psutil para obtener particiones
            partitions = psutil.disk_partitions(all=True)
            
            for partition in partitions:
                try:
                    # Obtener información del dispositivo
                    device_path = partition.device
                    mount_point = partition.mountpoint
                    fstype = partition.fstype
                    
                    # Saltar dispositivos del sistema
                    if self._should_skip_device(mount_point, fstype):
                        continue
                    
                    # Obtener tamaño
                    try:
                        usage = psutil.disk_usage(mount_point)
                        total_gb = usage.total / (1024**3)
                        available_gb = usage.free / (1024**3)
                        used_gb = usage.used / (1024**3)
                    except (OSError, PermissionError):
                        continue
                    
                    # Detectar tipo de dispositivo
                    device_type = self._detect_device_type(device_path, mount_point)
                    is_removable = self._is_removable(device_path)
                    
                    device = StorageDevice(
                        device_path=device_path,
                        mount_point=mount_point,
                        device_type=device_type,
                        total_size_gb=total_gb,
                        available_size_gb=available_gb,
                        used_size_gb=used_gb,
                        filesystem=fstype,
                        is_removable=is_removable
                    )
                    
                    self.devices.append(device)
                    logger.info(f"Dispositivo detectado: {device}")
                
                except Exception as e:
                    logger.warning(f"Error procesando partición {partition.device}: {e}")
        
        except Exception as e:
            logger.error(f"Error detectando dispositivos: {e}")
    
    def _should_skip_device(self, mount_point: str, fstype: str) -> bool:
        """Determina si un dispositivo debe ser ignorado"""
        skip_paths = [
            '/sys', '/proc', '/dev', '/run', '/boot',
            '/var', '/etc', '/tmp', '/root', '/home'
        ]
        skip_fs = ['tmpfs', 'devtmpfs', 'sysfs', 'proc', 'cgroup']
        
        # Saltar rutas del sistema
        for skip in skip_paths:
            if mount_point.startswith(skip):
                return True
        
        # Saltar filesystems del sistema
        if fstype in skip_fs:
            return True
        
        return False
    
    def _detect_device_type(self, device_path: str, mount_point: str) -> str:
        """Detecta el tipo de dispositivo"""
        device_lower = device_path.lower()
        
        # Detectar SSD
        if 'nvme' in device_lower or 'mmcblk' in device_lower:
            return 'ssd'
        
        # Detectar USB/Pendrive
        if 'sd' in device_lower and self._is_usb_device(device_path):
            return 'usb'
        
        # Detectar HDD
        if 'sd' in device_lower or 'hd' in device_lower:
            return 'hdd'
        
        # Detectar memoria local
        if mount_point == '/':
            return 'system'
        
        return 'unknown'
    
    def _is_usb_device(self, device_path: str) -> bool:
        """Verifica si es un dispositivo USB"""
        try:
            # Buscar en /sys/block para información de USB
            device_name = device_path.split('/')[-1].rstrip('0123456789')
            sys_path = f"/sys/block/{device_name}"
            
            if os.path.exists(sys_path):
                # Buscar "usb" en la jerarquía del dispositivo
                result = subprocess.run(
                    f"grep -l usb {sys_path}/*/uevent 2>/dev/null || true",
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=2
                )
                return bool(result.stdout.strip())
        except:
            pass
        
        return False
    
    def _is_removable(self, device_path: str) -> bool:
        """Verifica si el dispositivo es removible"""
        try:
            device_name = device_path.split('/')[-1].rstrip('0123456789')
            removable_path = f"/sys/block/{device_name}/removable"
            
            if os.path.exists(removable_path):
                with open(removable_path, 'r') as f:
                    return f.read().strip() == '1'
        except:
            pass
        
        return False
    
    def get_devices(self) -> List[StorageDevice]:
        """Retorna lista de dispositivos detectados"""
        return self.devices
    
    def get_device_by_path(self, mount_point: str) -> Optional[StorageDevice]:
        """Obtiene un dispositivo por su punto de montaje"""
        for device in self.devices:
            if device.mount_point == mount_point:
                return device
        return None
    
    def list_files(self, path: str, recursive: bool = False) -> List[Dict]:
        """Lista archivos en una ruta"""
        try:
            files = []
            path_obj = Path(path)
            
            if not path_obj.exists():
                logger.error(f"Ruta no existe: {path}")
                return []
            
            if recursive:
                items = path_obj.rglob('*')
            else:
                items = path_obj.iterdir()
            
            for item in items:
                try:
                    stat = item.stat()
                    files.append({
                        "name": item.name,
                        "path": str(item),
                        "is_dir": item.is_dir(),
                        "size_bytes": stat.st_size,
                        "size_mb": round(stat.st_size / (1024**2), 2),
                        "modified": stat.st_mtime,
                        "type": "folder" if item.is_dir() else item.suffix or "file"
                    })
                except (PermissionError, OSError):
                    continue
            
            return sorted(files, key=lambda x: (not x['is_dir'], x['name']))
        
        except Exception as e:
            logger.error(f"Error listando archivos en {path}: {e}")
            return []
    
    def get_storage_status(self) -> Dict:
        """Retorna estado completo del almacenamiento"""
        return {
            "devices": [device.to_dict() for device in self.devices],
            "total_devices": len(self.devices),
            "total_capacity_gb": sum(d.total_size_gb for d in self.devices),
            "total_available_gb": sum(d.available_size_gb for d in self.devices),
            "total_used_gb": sum(d.used_size_gb for d in self.devices)
        }


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("LOCAL STORAGE MANAGER - EJEMPLO")
    print("=" * 70)
    
    manager = LocalStorageManager()
    
    print("\n📊 Dispositivos Detectados:")
    for device in manager.get_devices():
        print(f"  {device}")
    
    print("\n📈 Estado General:")
    status = manager.get_storage_status()
    print(f"  Dispositivos: {status['total_devices']}")
    print(f"  Capacidad total: {status['total_capacity_gb']:.1f} GB")
    print(f"  Disponible: {status['total_available_gb']:.1f} GB")
    print(f"  Usado: {status['total_used_gb']:.1f} GB")
    
    # Listar archivos en home
    print("\n📁 Archivos en /home/ubuntu:")
    files = manager.list_files("/home/ubuntu", recursive=False)
    for f in files[:10]:
        icon = "📁" if f['is_dir'] else "📄"
        print(f"  {icon} {f['name']} ({f['size_mb']} MB)")
