"""
Terminator AliAmalia v1.0.0 — Suite de Tests Sprint 2
Ecosistema Gotham City — Exclusivo AliAmalia

Cubre: agent, memory, llm_bridge, reasoning, tools, personality, cli.
"""

import sys
import os
import pytest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: Importaciones
# ─────────────────────────────────────────────────────────────────────────────

class TestImports:
    def test_import_terminator(self):
        import terminator
        assert terminator is not None

    def test_import_agent(self):
        from terminator import TerminatorAgent
        assert TerminatorAgent is not None

    def test_import_memory(self):
        from terminator import MemoryManager
        assert MemoryManager is not None

    def test_import_memory_system_alias(self):
        from terminator.memory import MemorySystem
        assert MemorySystem is not None

    def test_import_llm_bridge(self):
        from terminator import LLMBridge
        assert LLMBridge is not None

    def test_import_reasoning(self):
        from terminator import ReasoningEngine
        assert ReasoningEngine is not None

    def test_import_tools(self):
        from terminator import ToolRegistry
        assert ToolRegistry is not None

    def test_import_personality(self):
        from terminator import PersonalityConfig
        assert PersonalityConfig is not None

    def test_import_personality_profile_alias(self):
        from terminator.personality import PersonalityProfile
        assert PersonalityProfile is not None

    def test_version(self):
        import terminator
        assert hasattr(terminator, '__version__')
        assert terminator.__version__ == "1.0.0"


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: MemoryManager
# ─────────────────────────────────────────────────────────────────────────────

class TestMemoryManager:
    """Tests del gestor de memoria del agente."""

    def test_memory_manager_instancia(self):
        from terminator import MemoryManager
        mm = MemoryManager()
        assert mm is not None

    def test_memory_manager_guardar_y_recuperar(self):
        from terminator import MemoryManager
        mm = MemoryManager()
        mm.store(key="test_key", value={"dato": "valor_de_prueba"})
        resultado = mm.retrieve(key="test_key")
        assert resultado is not None
        assert resultado.get("dato") == "valor_de_prueba"

    def test_memory_manager_clave_inexistente(self):
        from terminator import MemoryManager
        mm = MemoryManager()
        resultado = mm.retrieve(key="clave_que_no_existe_xyz")
        assert resultado is None

    def test_memory_manager_historial_conversacion(self):
        from terminator import MemoryManager
        mm = MemoryManager()
        mm.add_message(role="user", content="Hola, soy el usuario")
        mm.add_message(role="assistant", content="Hola, soy Terminator")
        historial = mm.get_history()
        assert len(historial) >= 2

    def test_memory_manager_limpiar_historial(self):
        from terminator import MemoryManager
        mm = MemoryManager()
        mm.add_message(role="user", content="Mensaje de prueba")
        mm.clear_history()
        historial = mm.get_history()
        assert len(historial) == 0

    def test_memory_system_alias_es_memory_manager(self):
        from terminator.memory import MemorySystem, MemoryManager
        assert MemorySystem is MemoryManager

    def test_memory_no_silencia_errores(self):
        """El módulo memory no debe silenciar errores de forma silenciosa."""
        from terminator import MemoryManager
        mm = MemoryManager()
        # Operación normal no debe lanzar excepción
        try:
            mm.store("k", "v")
            mm.retrieve("k")
        except Exception as e:
            pytest.fail(f"MemoryManager no debe lanzar excepción en operaciones normales: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: PersonalityConfig
# ─────────────────────────────────────────────────────────────────────────────

class TestPersonalityConfig:
    """Tests de la configuración de personalidad del agente."""

    def test_personality_config_instancia(self):
        from terminator import PersonalityConfig
        pc = PersonalityConfig()
        assert pc is not None

    def test_personality_config_nombre(self):
        from terminator import PersonalityConfig
        pc = PersonalityConfig(name="AliAmalia")
        assert pc.name == "AliAmalia"

    def test_personality_config_tono(self):
        from terminator import PersonalityConfig
        pc = PersonalityConfig(tone="amigable")
        assert pc.tone == "amigable"

    def test_personality_profile_alias(self):
        from terminator.personality import PersonalityProfile, PersonalityConfig
        assert PersonalityProfile is PersonalityConfig

    def test_personality_config_valores_por_defecto(self):
        from terminator import PersonalityConfig
        pc = PersonalityConfig()
        assert pc.name is not None
        assert pc.tone is not None


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: ToolRegistry
# ─────────────────────────────────────────────────────────────────────────────

class TestToolRegistry:
    """Tests del registro de herramientas del agente."""

    def test_tool_registry_instancia(self):
        from terminator import ToolRegistry
        tr = ToolRegistry()
        assert tr is not None

    def test_tool_registry_registrar_herramienta(self):
        from terminator import ToolRegistry

        def mi_herramienta(query: str) -> str:
            return f"Resultado: {query}"

        tr = ToolRegistry()
        tr.register(name="mi_herramienta", func=mi_herramienta,
                    description="Herramienta de prueba")
        assert tr.has_tool("mi_herramienta")

    def test_tool_registry_ejecutar_herramienta(self):
        from terminator import ToolRegistry

        def suma(a: int, b: int) -> int:
            return a + b

        tr = ToolRegistry()
        tr.register(name="suma", func=suma, description="Suma dos números")
        resultado = tr.execute("suma", a=3, b=4)
        # execute() siempre devuelve string (interfaz de herramientas de texto)
        assert str(resultado) == "7"

    def test_tool_registry_herramienta_inexistente(self):
        from terminator import ToolRegistry
        tr = ToolRegistry()
        assert not tr.has_tool("herramienta_que_no_existe")

    def test_tool_registry_listar_herramientas(self):
        from terminator import ToolRegistry
        tr = ToolRegistry()
        tr.register(name="h1", func=lambda: None, description="H1")
        tr.register(name="h2", func=lambda: None, description="H2")
        herramientas = tr.list_tools()
        assert "h1" in herramientas
        assert "h2" in herramientas


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: ReasoningEngine
# ─────────────────────────────────────────────────────────────────────────────

class TestReasoningEngine:
    """Tests del motor de razonamiento."""

    def test_reasoning_engine_instancia(self):
        from terminator import ReasoningEngine
        re = ReasoningEngine()
        assert re is not None

    def test_reasoning_engine_analizar(self):
        from terminator import ReasoningEngine
        re = ReasoningEngine()
        resultado = re.analyze("¿Cuál es la capital de España?")
        assert resultado is not None

    def test_reasoning_engine_plan(self):
        from terminator import ReasoningEngine
        re = ReasoningEngine()
        plan = re.plan("Necesito organizar una reunión")
        assert plan is not None


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: LLMBridge
# ─────────────────────────────────────────────────────────────────────────────

class TestLLMBridge:
    """Tests del puente LLM."""

    def test_llm_bridge_instancia(self):
        from terminator import LLMBridge
        bridge = LLMBridge()
        assert bridge is not None

    def test_llm_bridge_modos_disponibles(self):
        from terminator import LLMBridge
        bridge = LLMBridge()
        assert hasattr(bridge, 'mode')

    def test_llm_bridge_modo_local(self):
        from terminator import LLMBridge
        bridge = LLMBridge(mode="local")
        assert bridge.mode == "local"

    def test_llm_bridge_modo_api(self):
        from terminator import LLMBridge
        bridge = LLMBridge(mode="api")
        assert bridge.mode == "api"


# ─────────────────────────────────────────────────────────────────────────────
# TESTS: TerminatorAgent (integración)
# ─────────────────────────────────────────────────────────────────────────────

class TestTerminatorAgent:
    """Tests de integración del agente completo."""

    def test_agent_instancia(self):
        from terminator import TerminatorAgent
        agent = TerminatorAgent()
        assert agent is not None

    def test_agent_con_personalidad(self):
        from terminator import TerminatorAgent, PersonalityConfig
        pc = PersonalityConfig(name="AliAmalia", tone="profesional")
        agent = TerminatorAgent(personality=pc)
        assert agent is not None

    def test_agent_tiene_memoria(self):
        from terminator import TerminatorAgent
        agent = TerminatorAgent()
        assert hasattr(agent, 'memory')
        assert agent.memory is not None

    def test_agent_tiene_herramientas(self):
        from terminator import TerminatorAgent
        agent = TerminatorAgent()
        assert hasattr(agent, 'tools')
        assert agent.tools is not None

    def test_agent_tiene_razonamiento(self):
        from terminator import TerminatorAgent
        agent = TerminatorAgent()
        assert hasattr(agent, 'reasoning')
        assert agent.reasoning is not None

    def test_agent_procesar_mensaje(self):
        from terminator import TerminatorAgent
        agent = TerminatorAgent()
        respuesta = agent.process("Hola, ¿cómo estás?")
        assert respuesta is not None
        assert isinstance(respuesta, str)
        assert len(respuesta) > 0

    def test_agent_historial_conversacion(self):
        from terminator import TerminatorAgent
        agent = TerminatorAgent()
        agent.process("Primer mensaje")
        agent.process("Segundo mensaje")
        historial = agent.memory.get_history()
        assert len(historial) >= 2


# ─────────────────────────────────────────────────────────────────────────────
# PUNTO DE ENTRADA
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
