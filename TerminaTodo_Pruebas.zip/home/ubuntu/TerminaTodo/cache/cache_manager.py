"""
Cache Manager - Caché Inteligente
==================================

Módulo para cachear metadatos de archivos de forma inteligente.
"""

import json
import os
import time
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class CacheManager:
    """Gestor de caché inteligente para metadatos"""
    
    def __init__(self, cache_dir: str = "./.cache", ttl: int = 3600):
        """
        Inicializa el gestor de caché
        
        Args:
            cache_dir: Directorio para almacenar caché
            ttl: Tiempo de vida en segundos (por defecto 1 hora)
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl = ttl
        self.memory_cache: Dict[str, Dict[str, Any]] = {}
        self.access_count: Dict[str, int] = {}
    
    def _get_cache_key(self, storage_type: str, path: str) -> str:
        """Genera clave de caché"""
        key = f"{storage_type}:{path}"
        return hashlib.md5(key.encode()).hexdigest()
    
    def _get_cache_file(self, cache_key: str) -> Path:
        """Obtiene ruta del archivo de caché"""
        return self.cache_dir / f"{cache_key}.json"
    
    def get(self, storage_type: str, path: str) -> Optional[Dict]:
        """
        Obtiene datos del caché
        
        Args:
            storage_type: Tipo de almacenamiento
            path: Ruta del archivo/carpeta
            
        Returns:
            Dict con datos en caché o None si expiró
        """
        cache_key = self._get_cache_key(storage_type, path)
        
        # Verificar caché en memoria primero
        if cache_key in self.memory_cache:
            cached_data = self.memory_cache[cache_key]
            if not self._is_expired(cached_data):
                self.access_count[cache_key] = self.access_count.get(cache_key, 0) + 1
                return cached_data['data']
            else:
                del self.memory_cache[cache_key]
        
        # Verificar caché en disco
        cache_file = self._get_cache_file(cache_key)
        if cache_file.exists():
            try:
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
                
                if not self._is_expired(cached_data):
                    # Cargar en memoria
                    self.memory_cache[cache_key] = cached_data
                    self.access_count[cache_key] = self.access_count.get(cache_key, 0) + 1
                    return cached_data['data']
                else:
                    # Eliminar caché expirado
                    cache_file.unlink()
            except Exception as e:
                logger.error(f"Error leyendo caché: {e}")
        
        return None
    
    def set(self, storage_type: str, path: str, data: Dict, ttl: Optional[int] = None):
        """
        Almacena datos en caché
        
        Args:
            storage_type: Tipo de almacenamiento
            path: Ruta del archivo/carpeta
            data: Datos a cachear
            ttl: Tiempo de vida personalizado (opcional)
        """
        try:
            cache_key = self._get_cache_key(storage_type, path)
            ttl = ttl or self.ttl
            
            cached_data = {
                'timestamp': time.time(),
                'ttl': ttl,
                'data': data,
                'storage_type': storage_type,
                'path': path
            }
            
            # Almacenar en memoria
            self.memory_cache[cache_key] = cached_data
            
            # Almacenar en disco
            cache_file = self._get_cache_file(cache_key)
            with open(cache_file, 'w') as f:
                json.dump(cached_data, f)
            
            logger.debug(f"Datos cacheados: {cache_key}")
        except Exception as e:
            logger.error(f"Error almacenando en caché: {e}")
    
    def invalidate(self, storage_type: str, path: str):
        """Invalida caché de una ruta específica"""
        try:
            cache_key = self._get_cache_key(storage_type, path)
            
            # Eliminar de memoria
            if cache_key in self.memory_cache:
                del self.memory_cache[cache_key]
            
            # Eliminar de disco
            cache_file = self._get_cache_file(cache_key)
            if cache_file.exists():
                cache_file.unlink()
            
            logger.debug(f"Caché invalidado: {cache_key}")
        except Exception as e:
            logger.error(f"Error invalidando caché: {e}")
    
    def invalidate_all(self, storage_type: Optional[str] = None):
        """Invalida todo el caché o de un tipo específico"""
        try:
            if storage_type:
                # Invalidar solo de un tipo
                keys_to_delete = [
                    k for k, v in self.memory_cache.items()
                    if v.get('storage_type') == storage_type
                ]
                for key in keys_to_delete:
                    del self.memory_cache[key]
                
                # Limpiar disco
                for cache_file in self.cache_dir.glob("*.json"):
                    try:
                        with open(cache_file, 'r') as f:
                            data = json.load(f)
                            if data.get('storage_type') == storage_type:
                                cache_file.unlink()
                    except:
                        pass
            else:
                # Invalidar todo
                self.memory_cache.clear()
                for cache_file in self.cache_dir.glob("*.json"):
                    try:
                        cache_file.unlink()
                    except:
                        pass
            
            logger.info(f"Caché invalidado: {storage_type or 'todo'}")
        except Exception as e:
            logger.error(f"Error invalidando caché: {e}")
    
    def _is_expired(self, cached_data: Dict) -> bool:
        """Verifica si datos en caché han expirado"""
        timestamp = cached_data.get('timestamp', 0)
        ttl = cached_data.get('ttl', self.ttl)
        return time.time() - timestamp > ttl
    
    def get_stats(self) -> Dict:
        """Obtiene estadísticas del caché"""
        total_size = sum(
            os.path.getsize(f) for f in self.cache_dir.glob("*.json")
            if f.is_file()
        )
        
        return {
            'memory_items': len(self.memory_cache),
            'disk_items': len(list(self.cache_dir.glob("*.json"))),
            'disk_size_mb': total_size / (1024 * 1024),
            'total_accesses': sum(self.access_count.values()),
            'most_accessed': sorted(
                self.access_count.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]
        }
    
    def cleanup_expired(self):
        """Limpia archivos de caché expirados"""
        try:
            removed_count = 0
            for cache_file in self.cache_dir.glob("*.json"):
                try:
                    with open(cache_file, 'r') as f:
                        data = json.load(f)
                        if self._is_expired(data):
                            cache_file.unlink()
                            removed_count += 1
                except:
                    pass
            
            logger.info(f"Caché limpiado: {removed_count} archivos eliminados")
        except Exception as e:
            logger.error(f"Error limpiando caché: {e}")
    
    def clear_memory(self):
        """Limpia caché en memoria"""
        self.memory_cache.clear()
        self.access_count.clear()
        logger.info("Caché en memoria limpiado")
