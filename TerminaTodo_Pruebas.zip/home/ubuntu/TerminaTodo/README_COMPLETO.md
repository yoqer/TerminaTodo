# 🗂️ TerminaTodo Framework - Manual Completo

**Gestor Unificado de Almacenamiento Multi-Fuente con Sincronización, Caché y Monitoreo**

## 📋 Tabla de Contenidos

1. [Introducción](#introducción)
2. [Características Principales](#características-principales)
3. [Mejoras Implementadas](#mejoras-implementadas)
4. [Instalación](#instalación)
5. [Uso Básico](#uso-básico)
6. [Almacenamiento Local](#almacenamiento-local)
7. [Almacenamiento en Nube](#almacenamiento-en-nube)
8. [Hosting Privado](#hosting-privado)
9. [Sincronización Automática](#sincronización-automática)
10. [Caché Inteligente](#caché-inteligente)
11. [Monitoreo en Tiempo Real](#monitoreo-en-tiempo-real)
12. [Compresión Automática](#compresión-automática)
13. [Integración con Otros Frameworks](#integración-con-otros-frameworks)
14. [API REST](#api-rest)
15. [Interfaz Web](#interfaz-web)
16. [Casos de Uso Avanzados](#casos-de-uso-avanzados)
17. [Solución de Problemas](#solución-de-problemas)

---

## 🎯 Introducción

**TerminaTodo** es un framework profesional que unifica el acceso a múltiples tipos de almacenamiento:

- 💾 **Local**: SSD, HDD, pendrives, memoria
- ☁️ **Nube**: Google Drive, OneDrive, Dropbox
- 🖥️ **Hosting**: SFTP, FTP, HTTP/HTTPS

Con características avanzadas como sincronización automática, caché inteligente, monitoreo en tiempo real y compresión automática.

### ¿Para Qué Sirve?

TerminaTodo es ideal para:

1. **Científicos de Datos**: Acceder a datasets desde múltiples fuentes
2. **Ingenieros de ML**: Gestionar modelos y pesos en diferentes almacenamientos
3. **Desarrolladores**: Sincronizar código y configuraciones
4. **DevOps**: Monitorear cambios en archivos de configuración
5. **Equipos Distribuidos**: Compartir archivos entre miembros

### Especificidad del Framework

TerminaTodo es **único** porque:

- ✅ **Unificación Total**: Una interfaz para todo tipo de almacenamiento
- ✅ **Automático**: Sincronización, caché y compresión sin intervención
- ✅ **Inteligente**: Detecta cambios, optimiza acceso, comprime automáticamente
- ✅ **Escalable**: Desde 1 archivo a millones
- ✅ **Integrable**: Funciona con TenMiNaTor, Terminato, TERMINATOR

---

## ✨ Características Principales

### 🔍 Detección Automática

```python
from TerminaTodo import UnifiedStorageManager

manager = UnifiedStorageManager()

# Detecta automáticamente todo
summary = manager.get_storage_summary()
print(summary)
# {
#   'local': {'devices': 3, 'total_gb': 2000, 'available_gb': 1500},
#   'cloud': {'services': 2, 'authenticated': True},
#   'remote': {'servers': 1, 'connected': True}
# }
```

### 🎯 Búsqueda Global

```python
# Buscar en TODAS las fuentes simultáneamente
results = manager.search_files("*.pt", ["local", "cloud", "remote"])

for result in results:
    print(f"{result['storage_type']}: {result['name']} ({result['size_mb']}MB)")
```

### 🔗 Interfaz Unificada

```python
# Mismo código para cualquier tipo de almacenamiento
files = manager.list_all_files("local", "/home/ubuntu")
files = manager.list_all_files("cloud", "/My Drive")
files = manager.list_all_files("remote", "/data")
```

---

## 🚀 Mejoras Implementadas

### 1. 🔄 Sincronización Automática

**¿Qué es?** Sincroniza archivos automáticamente entre almacenamientos.

**¿Para qué sirve?**
- Mantener copias de seguridad
- Sincronizar datasets entre local y nube
- Replicar modelos entre servidores
- Backup automático

**¿Qué supone?**
- Ahorro de tiempo manual
- Garantía de consistencia
- Backup automático sin intervención

**Ejemplo:**

```python
from TerminaTodo import UnifiedStorageManager

manager = UnifiedStorageManager()

# Crear trabajo de sincronización
manager.sync_manager.add_job(
    job_id="sync_models",
    source_type="local",
    source_path="/home/ubuntu/models",
    dest_type="cloud",
    dest_path="/My Drive/Backups",
    bidirectional=True,  # Sincronización bidireccional
    interval=3600  # Cada hora
)

# Monitorear
status = manager.sync_manager.get_job_status("sync_models")
print(f"Sincronizados: {status['synced_files']} archivos")
```

### 2. 💾 Caché Inteligente

**¿Qué es?** Almacena metadatos de archivos para acceso rápido.

**¿Para qué sirve?**
- Acelerar búsquedas
- Reducir llamadas a API
- Mejorar rendimiento
- Funcionar offline

**¿Qué supone?**
- Búsquedas 100x más rápidas
- Menos uso de ancho de banda
- Funcionamiento offline parcial

**Ejemplo:**

```python
from TerminaTodo import UnifiedStorageManager

manager = UnifiedStorageManager()

# El caché es automático
files = manager.list_all_files("local", "/home/ubuntu")  # Cachea automáticamente

# Siguiente búsqueda es instantánea
files = manager.list_all_files("local", "/home/ubuntu")  # Desde caché

# Invalidar caché si es necesario
manager.cache_manager.invalidate("local", "/home/ubuntu")

# Ver estadísticas
stats = manager.cache_manager.get_stats()
print(f"Caché: {stats['memory_items']} items en memoria")
print(f"Tamaño disco: {stats['disk_size_mb']:.1f}MB")
```

### 3. 👁️ Monitoreo en Tiempo Real

**¿Qué es?** Detecta cambios en archivos en tiempo real.

**¿Para qué sirve?**
- Disparar acciones automáticas
- Alertas de cambios
- Sincronización reactiva
- Auditoría de cambios

**¿Qué supone?**
- Automatización completa
- Reactividad inmediata
- Trazabilidad total

**Ejemplo:**

```python
from TerminaTodo import FileWatcher

watcher = FileWatcher()

def on_file_change(change):
    print(f"{change.change_type.value}: {change.file_path}")
    
    # Sincronizar automáticamente
    if change.change_type.value == "modified":
        manager.sync_manager.add_job(...)

# Monitorear directorio
watcher.watch_directory(
    "watch_models",
    "/home/ubuntu/models",
    callback=on_file_change,
    recursive=True
)

# Mantener monitoreando
import time
time.sleep(3600)
```

### 4. 📦 Compresión Automática

**¿Qué es?** Comprime archivos automáticamente según criterios.

**¿Para qué sirve?**
- Ahorrar espacio
- Acelerar transferencias
- Archivar datos
- Reducir costos de almacenamiento

**¿Qué supone?**
- Ahorro de 50-80% en espacio
- Transferencias 10x más rápidas
- Costos reducidos

**Ejemplo:**

```python
from TerminaTodo import Compressor

compressor = Compressor()

# Verificar si debe comprimirse
should_compress, reason = compressor.should_compress("/home/ubuntu/data.csv")
print(f"Comprimir: {should_compress} ({reason})")

# Comprimir archivo
success, message = compressor.compress_file(
    "/home/ubuntu/data.csv",
    format="zip"
)
print(message)  # "Comprimido: 500.0KB -> 50.0KB (90.0% reducción)"

# Comprimir directorio
success, message = compressor.compress_directory(
    "/home/ubuntu/models",
    format="tar.gz"
)

# Descomprimir
success, message = compressor.decompress_file(
    "/home/ubuntu/data.csv.zip",
    "/home/ubuntu/extracted"
)
```

### 5. 🔗 Integración con Terminato

**¿Qué es?** Selecciona automáticamente datasets desde TerminaTodo en Terminato.

**¿Para qué sirve?**
- Flujo unificado de entrenamiento
- Acceso a datasets desde cualquier fuente
- Automatización completa

**Ejemplo:**

```python
from TerminaTodo import UnifiedStorageManager
from Terminato import TrainingManager

storage = UnifiedStorageManager()
trainer = TrainingManager()

# Buscar datasets
datasets = storage.search_files("dataset*.csv", ["local", "cloud"])

# Entrenar con cada dataset
for dataset in datasets:
    session = trainer.create_training_session(
        model_path="./model.pt",
        dataset_path=dataset['path'],
        gpu_id=0,
        nvme_path="/mnt/nvme1"
    )
    
    trainer.start_training(session)
```

---

## 📦 Instalación

### Opción 1: Desde PyPI (Recomendado)

```bash
pip install terminatodo
```

### Opción 2: Desde Código Fuente

```bash
# Descargar
unzip TerminaTodo_Complete.zip
cd TerminaTodo

# Instalar dependencias
pip install -r requirements.txt

# Instalar en modo desarrollo
pip install -e .
```

### Requisitos

- Python 3.10+
- 2 GB RAM mínimo
- Conexión a internet (para nube)

### Dependencias Opcionales

```bash
# Para monitoreo en tiempo real
pip install watchdog

# Para compresión avanzada
pip install py7zr

# Para integración con Google Drive
pip install google-auth-oauthlib

# Para integración con OneDrive
pip install microsoft-graph-core

# Para integración con Dropbox
pip install dropbox
```

---

## 🎯 Uso Básico

### Inicializar

```python
from TerminaTodo import UnifiedStorageManager

# Crear gestor
manager = UnifiedStorageManager()

# Ver resumen
summary = manager.get_storage_summary()
print(f"Local: {summary['local']['available_gb']}GB disponible")
print(f"Nube: {summary['cloud']['authenticated']} servicios autenticados")
```

### Listar Archivos

```python
# Local
files = manager.list_all_files("local", "/home/ubuntu")

# Nube
files = manager.list_all_files("cloud", "/My Drive")

# Remoto
files = manager.list_all_files("remote", "/data")

for f in files:
    icon = "📁" if f['is_dir'] else "📄"
    print(f"{icon} {f['name']} ({f['size_mb']}MB)")
```

### Buscar Archivos

```python
# Búsqueda simple
results = manager.search_files("*.py")

# Búsqueda en múltiples fuentes
results = manager.search_files("model*.pt", ["local", "cloud", "remote"])

# Búsqueda con patrones
results = manager.search_files("dataset_*.csv")
```

---

## 💾 Almacenamiento Local

### Detectar Dispositivos

```python
from TerminaTodo import LocalStorageManager

manager = LocalStorageManager()

# Obtener dispositivos
devices = manager.get_devices()

for device in devices:
    usage_pct = (device.used_size_gb / device.total_size_gb) * 100
    print(f"{device.mount_point}: {usage_pct:.1f}% lleno")
    print(f"  Tipo: {device.device_type}")
    print(f"  Disponible: {device.available_size_gb}GB")
```

### Explorar Directorios

```python
# Listar archivos
files = manager.list_files("/home/ubuntu")

# Listar recursivamente
files = manager.list_files("/home/ubuntu", recursive=True)

# Obtener información de archivo
info = manager.get_file_info("/home/ubuntu/file.txt")
print(f"Tamaño: {info['size_mb']}MB")
print(f"Modificado: {info['modified']}")
```

---

## ☁️ Almacenamiento en Nube

### Google Drive

```python
from TerminaTodo import CloudStorageManager

manager = CloudStorageManager()

# Autenticar (primera vez)
manager.authenticate_google_drive("credentials.json")

# Listar archivos
files = manager.list_files_google_drive()

# Buscar
results = manager.search_google_drive("*.csv")

# Descargar
manager.download_file("google_drive", "file_id", "./local_path")

# Subir
manager.upload_file("./local_file", "/My Drive/remote_path")
```

### OneDrive

```python
# Autenticar
manager.authenticate_onedrive(client_id, client_secret)

# Listar
files = manager.list_files_onedrive()

# Descargar
manager.download_file("onedrive", "item_id", "./local_path")
```

### Dropbox

```python
# Autenticar
manager.authenticate_dropbox("access_token")

# Listar
files = manager.list_files_dropbox()

# Descargar
manager.download_file("dropbox", "/path/file", "./local_path")
```

---

## 🖥️ Hosting Privado

### Configurar Servidor SFTP

```python
from TerminaTodo import RemoteStorageManager

manager = RemoteStorageManager()

# Añadir servidor
manager.add_server(
    server_id="sftp_prod",
    name="Servidor Producción",
    host="example.com",
    port=22,
    protocol="sftp",
    username="user",
    password="pass"
)

# Conectar
manager.connect_sftp("sftp_prod")

# Listar archivos
files = manager.list_files_sftp("sftp_prod", "/data")

# Descargar
manager.download_file_sftp("sftp_prod", "/data/model.pt", "./model.pt")

# Subir
manager.upload_file_sftp("sftp_prod", "./local.pt", "/data/remote.pt")
```

### Servidor HTTP

```python
# Añadir servidor HTTP
manager.add_server(
    server_id="http_api",
    name="API Server",
    host="api.example.com",
    port=443,
    protocol="https",
    api_key="your_api_key"
)

# Conectar
manager.connect_http("http_api")

# Listar
files = manager.list_files_http("http_api", "/files")
```

---

## 🔄 Sincronización Automática

### Crear Trabajo de Sincronización

```python
from TerminaTodo import UnifiedStorageManager

manager = UnifiedStorageManager()

# Sincronización unidireccional
manager.sync_manager.add_job(
    job_id="backup_local_to_cloud",
    source_type="local",
    source_path="/home/ubuntu/models",
    dest_type="cloud",
    dest_path="/My Drive/Backups/models",
    bidirectional=False,
    interval=3600  # Cada hora
)

# Sincronización bidireccional
manager.sync_manager.add_job(
    job_id="sync_datasets",
    source_type="local",
    source_path="/data/datasets",
    dest_type="remote",
    dest_path="/data/datasets",
    bidirectional=True,
    interval=1800  # Cada 30 minutos
)
```

### Monitorear Sincronización

```python
# Obtener estado
status = manager.sync_manager.get_job_status("backup_local_to_cloud")
print(f"Última sincronización: {status['last_sync']}")
print(f"Archivos sincronizados: {status['synced_files']}")
print(f"Errores: {status['errors']}")

# Obtener todos los trabajos
jobs = manager.sync_manager.get_all_jobs()
for job in jobs:
    print(f"{job['job_id']}: {job['source']} -> {job['dest']}")
```

### Callbacks de Sincronización

```python
def on_sync_start(data):
    print(f"Sincronización iniciada: {data['job_id']}")

def on_sync_complete(data):
    print(f"Sincronización completada: {data['synced']} archivos")

def on_file_synced(data):
    print(f"Archivo sincronizado: {data['file']}")

def on_error(data):
    print(f"Error: {data['error']}")

# Registrar callbacks
manager.sync_manager.register_callback('on_sync_start', on_sync_start)
manager.sync_manager.register_callback('on_sync_complete', on_sync_complete)
manager.sync_manager.register_callback('on_file_synced', on_file_synced)
manager.sync_manager.register_callback('on_error', on_error)
```

---

## 💾 Caché Inteligente

### Usar Caché

```python
from TerminaTodo import UnifiedStorageManager

manager = UnifiedStorageManager()

# Primera búsqueda: acceso a disco/API
files = manager.list_all_files("local", "/home/ubuntu")  # Lento

# Segunda búsqueda: desde caché
files = manager.list_all_files("local", "/home/ubuntu")  # Rápido (100x)
```

### Gestionar Caché

```python
# Invalidar caché específico
manager.cache_manager.invalidate("local", "/home/ubuntu")

# Invalidar todo el caché de un tipo
manager.cache_manager.invalidate_all("cloud")

# Invalidar todo
manager.cache_manager.invalidate_all()

# Limpiar archivos expirados
manager.cache_manager.cleanup_expired()

# Ver estadísticas
stats = manager.cache_manager.get_stats()
print(f"Items en memoria: {stats['memory_items']}")
print(f"Items en disco: {stats['disk_items']}")
print(f"Tamaño total: {stats['disk_size_mb']:.1f}MB")
print(f"Accesos totales: {stats['total_accesses']}")
```

### Configurar TTL

```python
# TTL global (por defecto 1 hora)
manager.cache_manager.ttl = 1800  # 30 minutos

# TTL específico
manager.cache_manager.set(
    "local",
    "/home/ubuntu",
    files_data,
    ttl=600  # 10 minutos
)
```

---

## 👁️ Monitoreo en Tiempo Real

### Monitorear Directorio

```python
from TerminaTodo import FileWatcher

watcher = FileWatcher()

def on_change(change):
    print(f"{change.change_type.value}: {change.file_path}")
    print(f"  Tamaño: {change.size_bytes} bytes")
    print(f"  Hora: {change.timestamp}")

# Monitorear
watcher.watch_directory(
    "watch_models",
    "/home/ubuntu/models",
    callback=on_change,
    recursive=True
)

# Ver monitores activos
watchers = watcher.get_watchers()
for w in watchers:
    print(f"{w['watch_id']}: {w['directory']}")

# Detener monitoreo
watcher.unwatch_directory("watch_models")
```

### Automatización Reactiva

```python
from TerminaTodo import FileWatcher, UnifiedStorageManager

watcher = FileWatcher()
manager = UnifiedStorageManager()

def on_model_change(change):
    if change.change_type.value == "modified":
        # Sincronizar automáticamente
        print(f"Sincronizando {change.file_path}...")
        # Código de sincronización

# Monitorear carpeta de modelos
watcher.watch_directory(
    "watch_models",
    "/home/ubuntu/models",
    callback=on_model_change
)
```

---

## 📦 Compresión Automática

### Comprimir Archivos

```python
from TerminaTodo import Compressor

compressor = Compressor()

# Verificar si debe comprimirse
should_compress, reason = compressor.should_compress("/home/ubuntu/data.csv")
print(f"Comprimir: {should_compress} ({reason})")

# Comprimir a ZIP
success, msg = compressor.compress_file(
    "/home/ubuntu/data.csv",
    format="zip"
)
print(msg)  # "Comprimido: 500.0KB -> 50.0KB (90.0% reducción)"

# Comprimir a TAR.GZ
success, msg = compressor.compress_file(
    "/home/ubuntu/data.csv",
    format="tar.gz"
)

# Comprimir a GZIP
success, msg = compressor.compress_file(
    "/home/ubuntu/data.csv",
    format="gz"
)
```

### Comprimir Directorios

```python
# Comprimir directorio completo
success, msg = compressor.compress_directory(
    "/home/ubuntu/models",
    format="tar.gz"
)
print(msg)  # "Directorio comprimido: 2500.5MB"
```

### Descomprimir

```python
# Descomprimir
success, msg = compressor.decompress_file(
    "/home/ubuntu/data.csv.zip",
    "/home/ubuntu/extracted"
)
print(msg)  # "Descomprimido en: /home/ubuntu/extracted"
```

### Calcular Ratio

```python
# Estimar ratio de compresión
ratio = compressor.get_compression_ratio("/home/ubuntu/data.csv")
print(f"Ratio esperado: {ratio:.1f}%")  # "Ratio esperado: 85.5%"
```

---

## 🔗 Integración con Otros Frameworks

### Con TenMiNaTor

```python
from TerminaTodo import UnifiedStorageManager
from TeMiNaTor import ModelFusion

storage = UnifiedStorageManager()
fusion = ModelFusion()

# Buscar modelos en nube
models = storage.search_files("*.pt", ["cloud"])

# Fusionarlos
for model in models:
    fusion.add_model(model['path'], model['name'])

fused_model = fusion.fuse_models(strategy='weighted')
```

### Con Terminato

```python
from TerminaTodo import UnifiedStorageManager
from Terminato import TrainingManager

storage = UnifiedStorageManager()
trainer = TrainingManager()

# Buscar datasets
datasets = storage.search_files("dataset*.csv", ["local", "cloud"])

# Entrenar con cada dataset
for dataset in datasets:
    session = trainer.create_training_session(
        model_path="./model.pt",
        dataset_path=dataset['path'],
        gpu_id=0
    )
    
    trainer.start_training(session)
```

### Con TERMINATOR

```python
from TerminaTodo import UnifiedStorageManager
from TERMINATOR import SteerableInference

storage = UnifiedStorageManager()
inference = SteerableInference()

# Buscar modelos
models = storage.search_files("model*.pt")

# Usar en inferencia
for model in models:
    results = inference.infer(
        model_path=model['path'],
        input_data=input_data,
        steering_vector=steering
    )
```

---

## 📡 API REST

### Endpoints Principales

```bash
# Resumen
GET /api/storage/summary

# Todos los almacenamientos
GET /api/storage/all

# Uso por tipo
GET /api/storage/usage

# Listar archivos
GET /api/files/list?storage_type=local&path=/home

# Buscar
GET /api/files/search?query=*.py&storage_types=local,cloud

# Información de archivo
GET /api/files/info?storage_type=local&path=/file

# Dispositivos locales
GET /api/local/devices

# Servicios en nube
GET /api/cloud/services

# Autenticar nube
POST /api/cloud/authenticate
{
  "service": "google_drive",
  "credentials": "..."
}

# Servidores remotos
GET /api/remote/servers
POST /api/remote/servers
POST /api/remote/connect/{server_id}
POST /api/remote/disconnect/{server_id}

# Sincronización
GET /api/sync/jobs
POST /api/sync/jobs
GET /api/sync/status/{job_id}

# Caché
GET /api/cache/stats
POST /api/cache/invalidate
POST /api/cache/cleanup

# Monitoreo
GET /api/watch/list
POST /api/watch/start
POST /api/watch/stop/{watch_id}

# Compresión
POST /api/compress/file
POST /api/compress/directory
POST /api/decompress/file
GET /api/compress/ratio
```

---

## 🌐 Interfaz Web

Acceso en: **http://localhost:8000**

### 5 Tabs Principales

1. **📊 Resumen** - Vista general de almacenamiento
2. **💾 Local** - Dispositivos y explorador
3. **☁️ Nube** - Autenticación y gestión
4. **🖥️ Hosting** - Configuración de servidores
5. **🔍 Búsqueda** - Búsqueda global

### Características

- ✅ Explorador visual
- ✅ Selección de dispositivos
- ✅ Autenticación con servicios
- ✅ Búsqueda en tiempo real
- ✅ Tema oscuro profesional
- ✅ Responsive design

---

## 💡 Casos de Uso Avanzados

### Caso 1: Pipeline de Ciencia de Datos

```python
from TerminaTodo import UnifiedStorageManager
from TenMiNaTor import ModelFusion
from Terminato import TrainingManager

storage = UnifiedStorageManager()
fusion = ModelFusion()
trainer = TrainingManager()

# 1. Buscar datasets en nube
datasets = storage.search_files("dataset*.csv", ["cloud"])

# 2. Descargar y cachear
for dataset in datasets:
    local_path = f"/data/{dataset['name']}"
    storage.download_file("cloud", dataset['path'], local_path)

# 3. Sincronizar con servidor remoto
storage.sync_manager.add_job(
    "sync_data",
    "local", "/data",
    "remote", "/data",
    bidirectional=True
)

# 4. Entrenar modelos
for dataset in datasets:
    session = trainer.create_training_session(
        dataset_path=f"/data/{dataset['name']}"
    )
    trainer.start_training(session)

# 5. Fusionar modelos entrenados
models = storage.search_files("model*.pt", ["local"])
for model in models:
    fusion.add_model(model['path'])

fused = fusion.fuse_models()

# 6. Comprimir y archivar
from TerminaTodo import Compressor
compressor = Compressor()
compressor.compress_file(fused, format="tar.gz")

# 7. Sincronizar resultado
storage.sync_manager.add_job(
    "backup_results",
    "local", "/results",
    "cloud", "/My Drive/Results"
)
```

### Caso 2: Monitoreo de Cambios Automático

```python
from TerminaTodo import FileWatcher, UnifiedStorageManager, Compressor

watcher = FileWatcher()
storage = UnifiedStorageManager()
compressor = Compressor()

def on_file_change(change):
    if change.change_type.value == "modified":
        file_path = change.file_path
        
        # 1. Comprimir si es grande
        if change.size_bytes > 100 * 1024 * 1024:  # > 100MB
            compressor.compress_file(file_path)
        
        # 2. Sincronizar a nube
        storage.sync_manager.add_job(
            f"sync_{file_path}",
            "local", file_path,
            "cloud", f"/My Drive/Backups/{file_path}"
        )
        
        # 3. Notificar
        print(f"✅ Archivo procesado: {file_path}")

# Monitorear carpeta de modelos
watcher.watch_directory(
    "watch_models",
    "/home/ubuntu/models",
    callback=on_file_change
)
```

### Caso 3: Integración Multi-Framework

```python
from TerminaTodo import UnifiedStorageManager
from TenMiNaTor import ModelFusion
from Terminato import TrainingManager
from TERMINATOR import SteerableInference

storage = UnifiedStorageManager()
fusion = ModelFusion()
trainer = TrainingManager()
inference = SteerableInference()

# Flujo completo
# 1. Buscar modelos base
base_models = storage.search_files("base_*.pt", ["cloud"])

# 2. Fusionarlos
for model in base_models:
    fusion.add_model(model['path'])
fused = fusion.fuse_models()

# 3. Fine-tuning
session = trainer.create_training_session(
    model_path=fused,
    dataset_path="/data/dataset.csv"
)
trainer.start_training(session)

# 4. Inferencia dirigida
results = inference.infer(
    model_path=fused,
    steering_vector=steering
)

# 5. Sincronizar resultados
storage.sync_manager.add_job(
    "backup_results",
    "local", "/results",
    "remote", "/results"
)
```

---

## 🆘 Solución de Problemas

### Problema: Dispositivo no detectado

```bash
# Ver dispositivos del sistema
lsblk
sudo fdisk -l

# Verificar permisos
ls -la /mnt/
sudo mount -l
```

### Problema: Error de conexión SFTP

```bash
# Verificar conectividad
ssh -v user@host

# Verificar puerto
nc -zv host 22

# Verificar credenciales
ssh user@host "ls -la"
```

### Problema: Nube no autenticada

- Verificar credenciales en `.env`
- Regenerar tokens de acceso
- Verificar permisos en aplicación en la nube

### Problema: Caché corrupto

```python
# Limpiar caché
manager.cache_manager.invalidate_all()
manager.cache_manager.cleanup_expired()
```

### Problema: Sincronización lenta

```python
# Aumentar intervalo
job = manager.sync_manager.jobs['job_id']
job.interval = 7200  # 2 horas

# O reducir cantidad de archivos
# Usar patrones más específicos
```

---

## 📊 Comparativa con Alternativas

| Característica | TerminaTodo | Rclone | S3cmd | Rsync |
|---|---|---|---|---|
| Múltiples fuentes | ✅ | ✅ | ❌ | ❌ |
| Interfaz web | ✅ | ❌ | ❌ | ❌ |
| Caché inteligente | ✅ | ❌ | ❌ | ❌ |
| Monitoreo tiempo real | ✅ | ❌ | ❌ | ❌ |
| Compresión automática | ✅ | ❌ | ❌ | ❌ |
| API REST | ✅ | ❌ | ❌ | ❌ |
| Integración ML | ✅ | ❌ | ❌ | ❌ |
| Python | ✅ | ✅ | ✅ | ❌ |

---

## 🎓 Recursos Adicionales

- **Documentación API**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **GitHub**: [Repositorio]
- **Ejemplos**: Ver carpeta `examples/`

---

## 📞 Soporte

- **Documentación**: http://localhost:8000/docs
- **Issues**: Reportar en GitHub
- **Email**: support@terminatodo.dev

---

**TerminaTodo v2.0.0**  
*Gestor Unificado de Almacenamiento Multi-Fuente*  
*Con Sincronización, Caché, Monitoreo y Compresión*  
*Listo para Producción*
