"""
TerminaTodo Framework
====================

Framework unificado para gestionar múltiples tipos de almacenamiento:
- Almacenamiento local (SSD, HDD, pendrives)
- Almacenamiento en nube (Google Drive, OneDrive, Dropbox)
- Hosting privado (servidores remotos)

Características:
- Detección automática de dispositivos
- Exploración de carpetas y archivos
- Integración con Terminato para entrenamientos
- API REST completa
- Interfaz web unificada
"""

__version__ = "1.0.0"
__author__ = "TerminaTodo Team"
__description__ = "Framework unificado de almacenamiento"

from .storage.local_storage import LocalStorageManager
from .cloud.cloud_manager import CloudStorageManager
from .hosting.remote_manager import RemoteStorageManager
from .storage.unified_manager import UnifiedStorageManager

__all__ = [
    "LocalStorageManager",
    "CloudStorageManager",
    "RemoteStorageManager",
    "UnifiedStorageManager",
]
