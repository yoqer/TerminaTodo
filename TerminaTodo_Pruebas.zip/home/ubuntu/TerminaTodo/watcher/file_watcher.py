"""
File Watcher - Monitoreo en Tiempo Real
========================================

Módulo para monitorear cambios en archivos en tiempo real.
"""

import os
import threading
import time
from pathlib import Path
from typing import Dict, List, Callable, Optional
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler, FileModifiedEvent
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    logger.warning("watchdog no disponible, usando polling")


class FileChangeType(Enum):
    """Tipos de cambios en archivos"""
    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"
    MOVED = "moved"


@dataclass
class FileChange:
    """Información sobre cambio en archivo"""
    change_type: FileChangeType
    file_path: str
    timestamp: datetime
    size_bytes: Optional[int] = None
    old_path: Optional[str] = None


class LocalFileEventHandler(FileSystemEventHandler):
    """Manejador de eventos del sistema de archivos"""
    
    def __init__(self, callback: Callable):
        self.callback = callback
    
    def on_created(self, event):
        if not event.is_directory:
            change = FileChange(
                change_type=FileChangeType.CREATED,
                file_path=event.src_path,
                timestamp=datetime.now(),
                size_bytes=os.path.getsize(event.src_path) if os.path.exists(event.src_path) else None
            )
            self.callback(change)
    
    def on_modified(self, event):
        if not event.is_directory:
            change = FileChange(
                change_type=FileChangeType.MODIFIED,
                file_path=event.src_path,
                timestamp=datetime.now(),
                size_bytes=os.path.getsize(event.src_path) if os.path.exists(event.src_path) else None
            )
            self.callback(change)
    
    def on_deleted(self, event):
        if not event.is_directory:
            change = FileChange(
                change_type=FileChangeType.DELETED,
                file_path=event.src_path,
                timestamp=datetime.now()
            )
            self.callback(change)
    
    def on_moved(self, event):
        if not event.is_directory:
            change = FileChange(
                change_type=FileChangeType.MOVED,
                file_path=event.dest_path,
                timestamp=datetime.now(),
                old_path=event.src_path,
                size_bytes=os.path.getsize(event.dest_path) if os.path.exists(event.dest_path) else None
            )
            self.callback(change)


class FileWatcher:
    """Monitorea cambios en archivos en tiempo real"""
    
    def __init__(self):
        """Inicializa el monitor de archivos"""
        self.watchers: Dict[str, Dict] = {}
        self.callbacks: Dict[str, List[Callable]] = {}
        self.running = True
        self.observer = None
        
        if WATCHDOG_AVAILABLE:
            self.observer = Observer()
            self.observer.start()
    
    def watch_directory(self, watch_id: str, directory: str, 
                       callback: Callable, recursive: bool = True) -> bool:
        """
        Monitorea un directorio
        
        Args:
            watch_id: ID único del monitor
            directory: Ruta del directorio
            callback: Función a llamar en cambios
            recursive: Si monitorear recursivamente
            
        Returns:
            bool: True si se inició correctamente
        """
        try:
            if not os.path.isdir(directory):
                logger.error(f"Directorio no existe: {directory}")
                return False
            
            if WATCHDOG_AVAILABLE:
                event_handler = LocalFileEventHandler(callback)
                watch = self.observer.schedule(
                    event_handler,
                    directory,
                    recursive=recursive
                )
                
                self.watchers[watch_id] = {
                    'directory': directory,
                    'watch': watch,
                    'recursive': recursive,
                    'callback': callback,
                    'created_at': datetime.now()
                }
            else:
                # Usar polling
                self.watchers[watch_id] = {
                    'directory': directory,
                    'recursive': recursive,
                    'callback': callback,
                    'created_at': datetime.now(),
                    'file_states': self._get_directory_state(directory, recursive)
                }
                
                # Iniciar thread de polling
                thread = threading.Thread(
                    target=self._poll_directory,
                    args=(watch_id,),
                    daemon=True
                )
                thread.start()
            
            logger.info(f"Monitor iniciado: {watch_id} -> {directory}")
            return True
        
        except Exception as e:
            logger.error(f"Error iniciando monitor: {e}")
            return False
    
    def unwatch_directory(self, watch_id: str) -> bool:
        """Detiene monitoreo de un directorio"""
        try:
            if watch_id in self.watchers:
                if WATCHDOG_AVAILABLE and 'watch' in self.watchers[watch_id]:
                    self.observer.unschedule(self.watchers[watch_id]['watch'])
                
                del self.watchers[watch_id]
                logger.info(f"Monitor detenido: {watch_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error deteniendo monitor: {e}")
            return False
    
    def _get_directory_state(self, directory: str, recursive: bool) -> Dict:
        """Obtiene estado actual del directorio"""
        state = {}
        try:
            if recursive:
                for root, dirs, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        state[file_path] = {
                            'size': os.path.getsize(file_path),
                            'mtime': os.path.getmtime(file_path)
                        }
            else:
                for file in os.listdir(directory):
                    file_path = os.path.join(directory, file)
                    if os.path.isfile(file_path):
                        state[file_path] = {
                            'size': os.path.getsize(file_path),
                            'mtime': os.path.getmtime(file_path)
                        }
        except Exception as e:
            logger.error(f"Error obteniendo estado: {e}")
        
        return state
    
    def _poll_directory(self, watch_id: str):
        """Thread de polling para directorios"""
        watcher = self.watchers.get(watch_id)
        if not watcher:
            return
        
        while watch_id in self.watchers and self.running:
            try:
                current_state = self._get_directory_state(
                    watcher['directory'],
                    watcher['recursive']
                )
                previous_state = watcher['file_states']
                
                # Detectar cambios
                for file_path, file_info in current_state.items():
                    if file_path not in previous_state:
                        # Archivo creado
                        change = FileChange(
                            change_type=FileChangeType.CREATED,
                            file_path=file_path,
                            timestamp=datetime.now(),
                            size_bytes=file_info['size']
                        )
                        watcher['callback'](change)
                    elif (file_info['size'] != previous_state[file_path]['size'] or
                          file_info['mtime'] != previous_state[file_path]['mtime']):
                        # Archivo modificado
                        change = FileChange(
                            change_type=FileChangeType.MODIFIED,
                            file_path=file_path,
                            timestamp=datetime.now(),
                            size_bytes=file_info['size']
                        )
                        watcher['callback'](change)
                
                # Detectar archivos eliminados
                for file_path in previous_state:
                    if file_path not in current_state:
                        change = FileChange(
                            change_type=FileChangeType.DELETED,
                            file_path=file_path,
                            timestamp=datetime.now()
                        )
                        watcher['callback'](change)
                
                watcher['file_states'] = current_state
                time.sleep(2)  # Polling cada 2 segundos
            
            except Exception as e:
                logger.error(f"Error en polling: {e}")
                time.sleep(5)
    
    def get_watchers(self) -> List[Dict]:
        """Obtiene lista de monitores activos"""
        result = []
        for watch_id, watcher in self.watchers.items():
            result.append({
                'watch_id': watch_id,
                'directory': watcher['directory'],
                'recursive': watcher['recursive'],
                'created_at': watcher['created_at'].isoformat()
            })
        return result
    
    def shutdown(self):
        """Detiene todos los monitores"""
        self.running = False
        
        for watch_id in list(self.watchers.keys()):
            self.unwatch_directory(watch_id)
        
        if WATCHDOG_AVAILABLE and self.observer:
            self.observer.stop()
            self.observer.join()
        
        logger.info("Monitor de archivos detenido")
