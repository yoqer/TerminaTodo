"""
TerminaTodo API
===============

API REST para gestionar múltiples tipos de almacenamiento.
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import logging
import sys
from pathlib import Path

# Añadir el directorio padre al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from storage.unified_manager import UnifiedStorageManager
from cloud.cloud_manager import CloudStorageManager
from hosting.remote_manager import RemoteStorageManager

logger = logging.getLogger(__name__)

# Crear app
app = FastAPI(
    title="TerminaTodo API",
    version="1.0.0",
    description="API unificada para gestión de almacenamiento"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Estado global
class AppState:
    def __init__(self):
        self.unified_manager = UnifiedStorageManager()
        self.initialized = False

state = AppState()


# Modelos Pydantic
class RemoteServerConfig(BaseModel):
    server_id: str
    name: str
    host: str
    port: int
    protocol: str  # sftp, ftp, http, https
    username: Optional[str] = None
    password: Optional[str] = None
    api_key: Optional[str] = None


class CloudAuthRequest(BaseModel):
    service: str  # google_drive, onedrive, dropbox
    credentials: str


# Endpoints

@app.on_event("startup")
async def startup():
    """Inicializa la aplicación"""
    logger.info("Iniciando TerminaTodo API...")
    state.initialized = True
    logger.info("TerminaTodo API iniciada")


@app.get("/")
async def root():
    """Endpoint raíz"""
    return {
        "name": "TerminaTodo API",
        "version": "1.0.0",
        "status": "running" if state.initialized else "initializing"
    }


@app.get("/health")
async def health_check():
    """Verifica el estado del sistema"""
    return {
        "status": "healthy" if state.initialized else "initializing"
    }


# Endpoints de Almacenamiento Unificado

@app.get("/api/storage/summary")
async def get_storage_summary():
    """Obtiene resumen de almacenamiento"""
    try:
        summary = state.unified_manager.get_storage_summary()
        return summary
    except Exception as e:
        logger.error(f"Error obteniendo resumen: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/storage/all")
async def get_all_storage():
    """Obtiene todos los tipos de almacenamiento"""
    try:
        storage = state.unified_manager.get_all_storage()
        return storage
    except Exception as e:
        logger.error(f"Error obteniendo almacenamiento: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/storage/usage")
async def get_storage_usage():
    """Obtiene uso de almacenamiento por tipo"""
    try:
        usage = state.unified_manager.get_storage_usage_by_type()
        return usage
    except Exception as e:
        logger.error(f"Error obteniendo uso: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/list")
async def list_files(
    storage_type: str = Query(..., description="Tipo: local, cloud, remote"),
    path: str = Query("/", description="Ruta a listar")
):
    """Lista archivos de un tipo de almacenamiento"""
    try:
        files = state.unified_manager.list_all_files(storage_type, path)
        return {"files": files, "count": len(files)}
    except Exception as e:
        logger.error(f"Error listando archivos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/search")
async def search_files(
    query: str = Query(..., description="Término de búsqueda"),
    storage_types: str = Query("local,cloud,remote", description="Tipos separados por coma")
):
    """Busca archivos en múltiples tipos de almacenamiento"""
    try:
        types = [t.strip() for t in storage_types.split(",")]
        results = state.unified_manager.search_files(query, types)
        return {"results": results, "count": len(results)}
    except Exception as e:
        logger.error(f"Error buscando archivos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/files/info")
async def get_file_info(
    storage_type: str = Query(...),
    path: str = Query(...)
):
    """Obtiene información de un archivo"""
    try:
        info = state.unified_manager.get_file_info(storage_type, path)
        if not info:
            raise HTTPException(status_code=404, detail="Archivo no encontrado")
        return info
    except Exception as e:
        logger.error(f"Error obteniendo información: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Endpoints de Almacenamiento Local

@app.get("/api/local/devices")
async def get_local_devices():
    """Obtiene dispositivos locales"""
    try:
        devices = state.unified_manager.local_manager.get_storage_status()
        return devices
    except Exception as e:
        logger.error(f"Error obteniendo dispositivos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Endpoints de Almacenamiento en Nube

@app.get("/api/cloud/services")
async def get_cloud_services():
    """Obtiene servicios en nube disponibles"""
    try:
        services = state.unified_manager.cloud_manager.get_available_services()
        return {"services": services}
    except Exception as e:
        logger.error(f"Error obteniendo servicios: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/cloud/authenticate")
async def authenticate_cloud(request: CloudAuthRequest):
    """Autentica con un servicio en nube"""
    try:
        service = request.service
        credentials = request.credentials
        
        if service == "google_drive":
            success = state.unified_manager.cloud_manager.authenticate_google_drive(credentials)
        elif service == "onedrive":
            success = state.unified_manager.cloud_manager.authenticate_onedrive(credentials)
        elif service == "dropbox":
            success = state.unified_manager.cloud_manager.authenticate_dropbox(credentials)
        else:
            raise HTTPException(status_code=400, detail="Servicio no válido")
        
        if not success:
            raise HTTPException(status_code=401, detail="Autenticación fallida")
        
        return {"status": "authenticated", "service": service}
    
    except Exception as e:
        logger.error(f"Error autenticando: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Endpoints de Hosting Privado

@app.post("/api/remote/servers")
async def add_remote_server(config: RemoteServerConfig):
    """Añade un servidor remoto"""
    try:
        success = state.unified_manager.remote_manager.add_server(
            server_id=config.server_id,
            name=config.name,
            host=config.host,
            port=config.port,
            protocol=config.protocol,
            username=config.username,
            password=config.password,
            api_key=config.api_key
        )
        
        if not success:
            raise HTTPException(status_code=400, detail="Error añadiendo servidor")
        
        return {"status": "added", "server_id": config.server_id}
    
    except Exception as e:
        logger.error(f"Error añadiendo servidor: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/remote/servers")
async def get_remote_servers():
    """Obtiene servidores remotos"""
    try:
        servers = state.unified_manager.remote_manager.get_remote_status()
        return servers
    except Exception as e:
        logger.error(f"Error obteniendo servidores: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/remote/connect/{server_id}")
async def connect_remote_server(server_id: str):
    """Conecta a un servidor remoto"""
    try:
        server = state.unified_manager.remote_manager.servers.get(server_id)
        if not server:
            raise HTTPException(status_code=404, detail="Servidor no encontrado")
        
        if server.protocol == "sftp":
            success = state.unified_manager.remote_manager.connect_sftp(server_id)
        elif server.protocol in ["http", "https"]:
            success = state.unified_manager.remote_manager.connect_http(server_id)
        else:
            raise HTTPException(status_code=400, detail="Protocolo no soportado")
        
        if not success:
            raise HTTPException(status_code=500, detail="Error conectando")
        
        return {"status": "connected", "server_id": server_id}
    
    except Exception as e:
        logger.error(f"Error conectando: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/remote/disconnect/{server_id}")
async def disconnect_remote_server(server_id: str):
    """Desconecta de un servidor remoto"""
    try:
        success = state.unified_manager.remote_manager.disconnect(server_id)
        
        if not success:
            raise HTTPException(status_code=500, detail="Error desconectando")
        
        return {"status": "disconnected", "server_id": server_id}
    
    except Exception as e:
        logger.error(f"Error desconectando: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Ejecutar servidor
if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
