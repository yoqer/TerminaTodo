"""
Remote Storage Manager
=====================

Gestiona acceso a hosting privado y servidores remotos:
- SFTP
- FTP
- HTTP/HTTPS
- SSH
"""

import logging
import paramiko
from typing import List, Dict, Optional
from dataclasses import dataclass
from datetime import datetime
import requests

logger = logging.getLogger(__name__)


@dataclass
class RemoteServer:
    """Información de un servidor remoto"""
    server_id: str
    name: str
    host: str
    port: int
    protocol: str  # sftp, ftp, http, ssh
    username: Optional[str] = None
    password: Optional[str] = None
    api_key: Optional[str] = None
    connected: bool = False
    
    def to_dict(self) -> Dict:
        return {
            "id": self.server_id,
            "name": self.name,
            "host": self.host,
            "port": self.port,
            "protocol": self.protocol,
            "connected": self.connected
        }


@dataclass
class RemoteFile:
    """Información de un archivo remoto"""
    name: str
    path: str
    is_folder: bool
    size_bytes: float
    modified: str
    server: str
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "path": self.path,
            "is_folder": self.is_folder,
            "size_mb": round(self.size_bytes / (1024**2), 2),
            "modified": self.modified,
            "server": self.server
        }


class RemoteStorageManager:
    """Gestor de almacenamiento remoto"""
    
    def __init__(self):
        self.servers: Dict[str, RemoteServer] = {}
        self.connections: Dict[str, object] = {}
    
    def add_server(
        self,
        server_id: str,
        name: str,
        host: str,
        port: int,
        protocol: str,
        username: Optional[str] = None,
        password: Optional[str] = None,
        api_key: Optional[str] = None
    ) -> bool:
        """Añade un servidor remoto"""
        try:
            server = RemoteServer(
                server_id=server_id,
                name=name,
                host=host,
                port=port,
                protocol=protocol,
                username=username,
                password=password,
                api_key=api_key
            )
            
            self.servers[server_id] = server
            logger.info(f"Servidor añadido: {name} ({protocol}://{host}:{port})")
            return True
        
        except Exception as e:
            logger.error(f"Error añadiendo servidor: {e}")
            return False
    
    def connect_sftp(self, server_id: str) -> bool:
        """Conecta a un servidor SFTP"""
        try:
            if server_id not in self.servers:
                logger.error(f"Servidor {server_id} no encontrado")
                return False
            
            server = self.servers[server_id]
            
            if server.protocol != 'sftp':
                logger.error(f"Servidor {server_id} no es SFTP")
                return False
            
            logger.info(f"Conectando a SFTP: {server.host}:{server.port}")
            
            # Crear cliente SSH
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            # Conectar
            ssh.connect(
                server.host,
                port=server.port,
                username=server.username,
                password=server.password,
                timeout=10
            )
            
            # Crear cliente SFTP
            sftp = ssh.open_sftp()
            
            self.connections[server_id] = {
                'ssh': ssh,
                'sftp': sftp,
                'type': 'sftp'
            }
            
            server.connected = True
            logger.info(f"SFTP conectado: {server.name}")
            return True
        
        except Exception as e:
            logger.error(f"Error conectando SFTP: {e}")
            return False
    
    def connect_http(self, server_id: str) -> bool:
        """Conecta a un servidor HTTP/HTTPS"""
        try:
            if server_id not in self.servers:
                logger.error(f"Servidor {server_id} no encontrado")
                return False
            
            server = self.servers[server_id]
            
            if server.protocol not in ['http', 'https']:
                logger.error(f"Servidor {server_id} no es HTTP/HTTPS")
                return False
            
            logger.info(f"Conectando a {server.protocol.upper()}: {server.host}:{server.port}")
            
            # Verificar conectividad
            protocol = 'https' if server.protocol == 'https' else 'http'
            url = f"{protocol}://{server.host}:{server.port}"
            
            headers = {}
            if server.api_key:
                headers['Authorization'] = f"Bearer {server.api_key}"
            
            response = requests.get(url, headers=headers, timeout=5)
            
            if response.status_code < 400:
                self.connections[server_id] = {
                    'url': url,
                    'headers': headers,
                    'type': 'http'
                }
                
                server.connected = True
                logger.info(f"HTTP conectado: {server.name}")
                return True
            else:
                logger.error(f"Error conectando HTTP: {response.status_code}")
                return False
        
        except Exception as e:
            logger.error(f"Error conectando HTTP: {e}")
            return False
    
    def list_files_sftp(self, server_id: str, path: str = '/') -> List[RemoteFile]:
        """Lista archivos en servidor SFTP"""
        try:
            if server_id not in self.connections:
                logger.error(f"Servidor {server_id} no conectado")
                return []
            
            conn = self.connections[server_id]
            if conn['type'] != 'sftp':
                logger.error(f"Servidor {server_id} no es SFTP")
                return []
            
            sftp = conn['sftp']
            server = self.servers[server_id]
            
            logger.info(f"Listando archivos SFTP en {path}")
            
            files = []
            try:
                items = sftp.listdir_attr(path)
                
                for item in items:
                    file = RemoteFile(
                        name=item.filename,
                        path=f"{path}/{item.filename}".replace('//', '/'),
                        is_folder=item.filename.startswith('d') or (hasattr(item, 'st_mode') and 
                                  item.st_mode and (item.st_mode & 0o40000)),
                        size_bytes=item.st_size,
                        modified=datetime.fromtimestamp(item.st_mtime).isoformat(),
                        server=server.name
                    )
                    files.append(file)
            
            except Exception as e:
                logger.warning(f"Error listando carpeta {path}: {e}")
            
            return files
        
        except Exception as e:
            logger.error(f"Error listando archivos SFTP: {e}")
            return []
    
    def list_files_http(self, server_id: str, path: str = '/') -> List[RemoteFile]:
        """Lista archivos en servidor HTTP"""
        try:
            if server_id not in self.connections:
                logger.error(f"Servidor {server_id} no conectado")
                return []
            
            conn = self.connections[server_id]
            if conn['type'] != 'http':
                logger.error(f"Servidor {server_id} no es HTTP")
                return []
            
            server = self.servers[server_id]
            url = conn['url']
            headers = conn['headers']
            
            logger.info(f"Listando archivos HTTP en {path}")
            
            # Hacer request a la API
            api_url = f"{url}/api/files?path={path}"
            response = requests.get(api_url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                files = []
                
                for item in data.get('files', []):
                    file = RemoteFile(
                        name=item.get('name', ''),
                        path=item.get('path', ''),
                        is_folder=item.get('is_folder', False),
                        size_bytes=item.get('size', 0),
                        modified=item.get('modified', datetime.now().isoformat()),
                        server=server.name
                    )
                    files.append(file)
                
                return files
            else:
                logger.error(f"Error en HTTP: {response.status_code}")
                return []
        
        except Exception as e:
            logger.error(f"Error listando archivos HTTP: {e}")
            return []
    
    def download_file_sftp(self, server_id: str, remote_path: str, local_path: str) -> bool:
        """Descarga un archivo desde SFTP"""
        try:
            if server_id not in self.connections:
                logger.error(f"Servidor {server_id} no conectado")
                return False
            
            conn = self.connections[server_id]
            sftp = conn['sftp']
            
            logger.info(f"Descargando {remote_path} desde SFTP")
            sftp.get(remote_path, local_path)
            
            logger.info(f"Archivo descargado a {local_path}")
            return True
        
        except Exception as e:
            logger.error(f"Error descargando archivo SFTP: {e}")
            return False
    
    def disconnect(self, server_id: str) -> bool:
        """Desconecta de un servidor"""
        try:
            if server_id not in self.connections:
                return True
            
            conn = self.connections[server_id]
            
            if conn['type'] == 'sftp':
                conn['sftp'].close()
                conn['ssh'].close()
            
            del self.connections[server_id]
            self.servers[server_id].connected = False
            
            logger.info(f"Desconectado de {server_id}")
            return True
        
        except Exception as e:
            logger.error(f"Error desconectando: {e}")
            return False
    
    def get_servers(self) -> List[Dict]:
        """Retorna lista de servidores"""
        return [server.to_dict() for server in self.servers.values()]
    
    def get_remote_status(self) -> Dict:
        """Retorna estado de servidores remotos"""
        return {
            "total_servers": len(self.servers),
            "connected_servers": sum(1 for s in self.servers.values() if s.connected),
            "servers": self.get_servers()
        }


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("REMOTE STORAGE MANAGER - EJEMPLO")
    print("=" * 70)
    
    manager = RemoteStorageManager()
    
    # Añadir servidor de ejemplo
    manager.add_server(
        server_id="sftp_server",
        name="Mi Servidor SFTP",
        host="example.com",
        port=22,
        protocol="sftp",
        username="user",
        password="pass"
    )
    
    print("\n🖥️ Servidores Configurados:")
    for server in manager.get_servers():
        print(f"  {server['name']} ({server['protocol']}://{server['host']}:{server['port']})")
    
    print("\n📊 Estado:")
    status = manager.get_remote_status()
    print(f"  Total: {status['total_servers']}")
    print(f"  Conectados: {status['connected_servers']}")
