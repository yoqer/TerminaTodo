"""
Sync Manager - Sincronización Automática
==========================================

Módulo para sincronizar archivos entre múltiples tipos de almacenamiento.
"""

import os
import hashlib
import threading
import time
from pathlib import Path
from typing import Dict, List, Callable, Optional
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class SyncJob:
    """Configuración de trabajo de sincronización"""
    job_id: str
    source_type: str  # local, cloud, remote
    source_path: str
    dest_type: str
    dest_path: str
    bidirectional: bool = False
    interval: int = 300  # segundos
    enabled: bool = True
    created_at: datetime = None
    last_sync: datetime = None
    file_count: int = 0
    error_count: int = 0


class SyncManager:
    """Gestor de sincronización automática"""
    
    def __init__(self, unified_manager):
        """
        Inicializa el gestor de sincronización
        
        Args:
            unified_manager: Instancia de UnifiedStorageManager
        """
        self.unified_manager = unified_manager
        self.jobs: Dict[str, SyncJob] = {}
        self.threads: Dict[str, threading.Thread] = {}
        self.file_hashes: Dict[str, str] = {}
        self.callbacks: Dict[str, List[Callable]] = {
            'on_sync_start': [],
            'on_sync_complete': [],
            'on_file_synced': [],
            'on_error': []
        }
        self.running = True
    
    def add_job(self, job_id: str, source_type: str, source_path: str,
                dest_type: str, dest_path: str, bidirectional: bool = False,
                interval: int = 300) -> bool:
        """
        Añade un trabajo de sincronización
        
        Args:
            job_id: ID único del trabajo
            source_type: Tipo de almacenamiento origen (local, cloud, remote)
            source_path: Ruta en origen
            dest_type: Tipo de almacenamiento destino
            dest_path: Ruta en destino
            bidirectional: Si es bidireccional
            interval: Intervalo en segundos
            
        Returns:
            bool: True si se añadió correctamente
        """
        try:
            job = SyncJob(
                job_id=job_id,
                source_type=source_type,
                source_path=source_path,
                dest_type=dest_type,
                dest_path=dest_path,
                bidirectional=bidirectional,
                interval=interval,
                created_at=datetime.now()
            )
            
            self.jobs[job_id] = job
            logger.info(f"Trabajo de sincronización añadido: {job_id}")
            
            # Iniciar thread
            self._start_sync_thread(job_id)
            
            return True
        except Exception as e:
            logger.error(f"Error añadiendo trabajo: {e}")
            self._trigger_callback('on_error', {'error': str(e)})
            return False
    
    def remove_job(self, job_id: str) -> bool:
        """Elimina un trabajo de sincronización"""
        try:
            if job_id in self.jobs:
                self.jobs[job_id].enabled = False
                del self.jobs[job_id]
                logger.info(f"Trabajo eliminado: {job_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error eliminando trabajo: {e}")
            return False
    
    def _start_sync_thread(self, job_id: str):
        """Inicia thread de sincronización para un trabajo"""
        def sync_worker():
            job = self.jobs[job_id]
            while job.enabled and self.running:
                try:
                    self._sync_job(job_id)
                    time.sleep(job.interval)
                except Exception as e:
                    logger.error(f"Error en sincronización {job_id}: {e}")
                    self._trigger_callback('on_error', {'job_id': job_id, 'error': str(e)})
                    time.sleep(job.interval)
        
        thread = threading.Thread(target=sync_worker, daemon=True)
        thread.start()
        self.threads[job_id] = thread
    
    def _sync_job(self, job_id: str):
        """Ejecuta sincronización de un trabajo"""
        job = self.jobs[job_id]
        
        self._trigger_callback('on_sync_start', {'job_id': job_id})
        
        try:
            # Obtener archivos del origen
            source_files = self.unified_manager.list_all_files(
                job.source_type,
                job.source_path
            )
            
            synced_count = 0
            error_count = 0
            
            for file_info in source_files:
                try:
                    # Calcular hash
                    file_hash = self._get_file_hash(
                        job.source_type,
                        file_info['path']
                    )
                    
                    # Verificar si ya está sincronizado
                    cache_key = f"{job.source_type}:{file_info['path']}"
                    if cache_key in self.file_hashes and self.file_hashes[cache_key] == file_hash:
                        continue
                    
                    # Sincronizar archivo
                    dest_file_path = os.path.join(
                        job.dest_path,
                        os.path.basename(file_info['path'])
                    )
                    
                    self._sync_file(
                        job.source_type,
                        file_info['path'],
                        job.dest_type,
                        dest_file_path
                    )
                    
                    # Actualizar hash
                    self.file_hashes[cache_key] = file_hash
                    synced_count += 1
                    
                    self._trigger_callback('on_file_synced', {
                        'file': file_info['name'],
                        'source': job.source_type,
                        'dest': job.dest_type
                    })
                    
                except Exception as e:
                    logger.error(f"Error sincronizando {file_info['path']}: {e}")
                    error_count += 1
            
            # Sincronización bidireccional
            if job.bidirectional:
                dest_files = self.unified_manager.list_all_files(
                    job.dest_type,
                    job.dest_path
                )
                
                for file_info in dest_files:
                    try:
                        source_file_path = os.path.join(
                            job.source_path,
                            os.path.basename(file_info['path'])
                        )
                        
                        self._sync_file(
                            job.dest_type,
                            file_info['path'],
                            job.source_type,
                            source_file_path
                        )
                        
                        synced_count += 1
                        
                    except Exception as e:
                        logger.error(f"Error en sincronización bidireccional: {e}")
                        error_count += 1
            
            job.last_sync = datetime.now()
            job.file_count = synced_count
            job.error_count = error_count
            
            self._trigger_callback('on_sync_complete', {
                'job_id': job_id,
                'synced': synced_count,
                'errors': error_count
            })
            
        except Exception as e:
            logger.error(f"Error en trabajo de sincronización {job_id}: {e}")
            job.error_count += 1
            self._trigger_callback('on_error', {'job_id': job_id, 'error': str(e)})
    
    def _sync_file(self, source_type: str, source_path: str,
                   dest_type: str, dest_path: str):
        """Sincroniza un archivo individual"""
        # Descargar del origen
        temp_file = f"/tmp/sync_{int(time.time())}"
        
        if source_type == "local":
            # Copiar localmente
            import shutil
            shutil.copy2(source_path, temp_file)
        elif source_type == "cloud":
            # Descargar de nube
            self.unified_manager.cloud_manager.download_file(
                source_path,
                temp_file
            )
        elif source_type == "remote":
            # Descargar de servidor remoto
            self.unified_manager.remote_manager.download_file(
                source_path,
                temp_file
            )
        
        # Subir al destino
        if dest_type == "local":
            import shutil
            shutil.copy2(temp_file, dest_path)
        elif dest_type == "cloud":
            self.unified_manager.cloud_manager.upload_file(
                temp_file,
                dest_path
            )
        elif dest_type == "remote":
            self.unified_manager.remote_manager.upload_file(
                temp_file,
                dest_path
            )
        
        # Limpiar temporal
        if os.path.exists(temp_file):
            os.remove(temp_file)
    
    def _get_file_hash(self, storage_type: str, file_path: str) -> str:
        """Calcula hash MD5 de un archivo"""
        try:
            if storage_type == "local":
                with open(file_path, 'rb') as f:
                    return hashlib.md5(f.read()).hexdigest()
            else:
                # Para archivos remotos, usar tamaño + fecha modificación
                info = self.unified_manager.get_file_info(storage_type, file_path)
                return hashlib.md5(
                    f"{info['size_mb']}{info['modified']}".encode()
                ).hexdigest()
        except Exception as e:
            logger.error(f"Error calculando hash: {e}")
            return ""
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Obtiene estado de un trabajo"""
        if job_id not in self.jobs:
            return None
        
        job = self.jobs[job_id]
        return {
            'job_id': job_id,
            'source': f"{job.source_type}:{job.source_path}",
            'dest': f"{job.dest_type}:{job.dest_path}",
            'bidirectional': job.bidirectional,
            'enabled': job.enabled,
            'last_sync': job.last_sync.isoformat() if job.last_sync else None,
            'synced_files': job.file_count,
            'errors': job.error_count,
            'interval': job.interval
        }
    
    def get_all_jobs(self) -> List[Dict]:
        """Obtiene estado de todos los trabajos"""
        return [self.get_job_status(job_id) for job_id in self.jobs]
    
    def register_callback(self, event: str, callback: Callable):
        """Registra callback para eventos"""
        if event in self.callbacks:
            self.callbacks[event].append(callback)
    
    def _trigger_callback(self, event: str, data: Dict):
        """Dispara callbacks registrados"""
        if event in self.callbacks:
            for callback in self.callbacks[event]:
                try:
                    callback(data)
                except Exception as e:
                    logger.error(f"Error en callback {event}: {e}")
    
    def shutdown(self):
        """Detiene todos los trabajos de sincronización"""
        self.running = False
        for job_id in list(self.jobs.keys()):
            self.jobs[job_id].enabled = False
        logger.info("Gestor de sincronización detenido")
