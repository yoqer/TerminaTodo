#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name="terminatodo",
    version="2.0.0",
    author="yoqer",
    description="Gestor unificado de almacenamiento multi-fuente",
    url="https://github.com/yoqer/TerminaTodo",
    packages=find_packages(exclude=["tests", "examples"]),
    python_requires=">=3.8",
    install_requires=["watchdog>=2.1.0", "pyyaml>=6.0", "requests>=2.28.0"],
    extras_require={
        "cloud": ["google-auth>=2.0.0", "google-cloud-storage>=2.0.0", "dropbox>=11.0.0"],
        "pytorch": ["torch>=1.10.0", "torchvision>=0.11.0"],
        "tensorflow": ["tensorflow>=2.8.0"],
        "nlp": ["transformers>=4.15.0", "spacy>=3.2.0"],
        "vision": ["opencv-python>=4.5.0"],
        "audio": ["librosa>=0.9.0"],
        "tenminatorch": ["tenminatorch>=1.0.0"],
        "teminador": ["teminador>=1.0.0"],
        "terminato": ["terminato>=1.0.0"],
        "terminator": ["terminator>=1.0.0"],
        "all": ["torch>=1.10.0", "tensorflow>=2.8.0", "transformers>=4.15.0"],
    },
)
